import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRightLeft, Plus, Calendar, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO } from "date-fns";
import ShiftCard from "@/components/shifts/shift-card";

export default function ShiftTrading() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isPostDialogOpen, setIsPostDialogOpen] = useState(false);
  const [selectedShiftId, setSelectedShiftId] = useState("");
  const [reason, setReason] = useState("");
  const [urgency, setUrgency] = useState<"low" | "medium" | "high">("medium");

  const { data: availableShifts } = useQuery({
    queryKey: ["/api/shift-trades/available"],
  });

  const { data: myTrades } = useQuery({
    queryKey: ["/api/shift-trades"],
  });

  // Fetch user's upcoming shifts
  const { data: myShifts, isLoading: shiftsLoading } = useQuery({
    queryKey: ["my-shifts-for-trade"],
    queryFn: async () => {
      // Get shifts from today onwards
      const now = new Date();
      now.setHours(0, 0, 0, 0);
      const futureDate = new Date();
      futureDate.setMonth(futureDate.getMonth() + 1);
      futureDate.setHours(23, 59, 59, 999);
      const response = await apiRequest('GET', `/api/shifts?startDate=${now.toISOString()}&endDate=${futureDate.toISOString()}`);
      const data = await response.json();
      console.log('Fetched shifts for trade:', data);
      return data;
    },
    enabled: isPostDialogOpen, // Only fetch when dialog is open
  });

  // Post shift trade mutation
  const postTradeMutation = useMutation({
    mutationFn: async (data: { shiftId: string; reason: string; urgency: string }) => {
      const response = await apiRequest('POST', '/api/shift-trades', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shift-trades"] });
      queryClient.invalidateQueries({ queryKey: ["/api/shift-trades/available"] });
      toast({
        title: "Success",
        description: "Shift posted for trade successfully",
      });
      setIsPostDialogOpen(false);
      setSelectedShiftId("");
      setReason("");
      setUrgency("medium");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to post shift for trade",
        variant: "destructive",
      });
    },
  });

  const handlePostShift = () => {
    if (!selectedShiftId) {
      toast({
        title: "Error",
        description: "Please select a shift to trade",
        variant: "destructive",
      });
      return;
    }
    if (!reason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for trading",
        variant: "destructive",
      });
      return;
    }
    postTradeMutation.mutate({ shiftId: selectedShiftId, reason, urgency });
  };

  // Filter to get only future shifts that haven't been traded yet
  const upcomingShifts = (myShifts?.shifts || []).filter((shift: any) => {
    const shiftDate = new Date(shift.startTime);
    return shiftDate >= new Date();
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Shift Trading</h2>
          <p className="text-muted-foreground">Exchange shifts with your colleagues</p>
        </div>

        <Button data-testid="button-post-shift" onClick={() => setIsPostDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Post Available Shift
        </Button>
      </div>

      {/* Post Shift Dialog */}
      <Dialog open={isPostDialogOpen} onOpenChange={setIsPostDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Post Shift for Trade</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Shift</Label>
              {shiftsLoading ? (
                <div className="p-4 text-center text-muted-foreground">Loading shifts...</div>
              ) : (
                <Select value={selectedShiftId} onValueChange={setSelectedShiftId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a shift to trade" />
                  </SelectTrigger>
                  <SelectContent>
                    {upcomingShifts.length > 0 ? (
                      upcomingShifts.map((shift: any) => (
                        <SelectItem key={shift.id} value={shift.id}>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>{format(new Date(shift.startTime), "MMM d, yyyy")}</span>
                            <Clock className="h-4 w-4 ml-2" />
                            <span>{format(new Date(shift.startTime), "h:mm a")} - {format(new Date(shift.endTime), "h:mm a")}</span>
                          </div>
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="none" disabled>No upcoming shifts available</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="space-y-2">
              <Label>Urgency</Label>
              <Select value={urgency} onValueChange={(v) => setUrgency(v as "low" | "medium" | "high")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Reason for Trading</Label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Why do you need to trade this shift?"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPostDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePostShift} disabled={postTradeMutation.isPending}>
              {postTradeMutation.isPending ? "Posting..." : "Post Shift"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Available Shifts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <ArrowRightLeft className="h-5 w-5 text-primary mr-2" />
              Available Shifts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {availableShifts?.trades?.length > 0 ? (
                availableShifts.trades.map((trade: any) => (
                  <ShiftCard
                    key={trade.id}
                    trade={trade}
                    type="available"
                    data-testid={`shift-available-${trade.id}`}
                  />
                ))
              ) : (
                <p className="text-muted-foreground text-center py-4">
                  No available shifts to trade
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* My Posted Shifts */}
        <Card>
          <CardHeader>
            <CardTitle>My Posted Shifts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {myTrades?.trades?.length > 0 ? (
                myTrades.trades.map((trade: any) => (
                  <ShiftCard
                    key={trade.id}
                    trade={trade}
                    type="my"
                    data-testid={`shift-my-${trade.id}`}
                  />
                ))
              ) : (
                <p className="text-muted-foreground text-center py-4">
                  You haven't posted any shifts for trade
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
